disp('percepetron network for /NAND/ function bipolar inputs and targets');
%input patern
x1=[-1 -1 1 1];
%bias input
x2=[-1 1 -1 1];
%target vector
t =[1 1 1 -1 ];
w1=-1;
w2=1;
%initial weights and bias
b=-0.5;
%initializing learning rate
alpha=0.1;
%error convergence
e=2;
%change in weights and bias
delw1=0;
delw2=0;
delb=0;
epoch=0;
while (e>0)
    epoch=epoch+1;
    e=0;
    for i = 1:4
        u(i)=w1*x1(i)+w2*x2(i)+b;
        if u(i)>=0
            y(i)=1;
        else
            y(i)=-1;
        end
        if (y(i)~=t(i))
            %net input calculated and target
            delw1=alpha*t(i)*x1(i);
            delw2=alpha*t(i)*x2(i);
            delb=alpha*t(i);
            %update of weights
            w1=w1+delw1;
            w2=w2+delw2;
            b=b+delb;
            %new weights
            w=[w1 w2 b];
        end
        e=e+(t(i)-y(i))^2;
    end

disp('The error /e/is:');disp(e);
disp('epoch /epoch/is:');disp(epoch);
end